Press F8 to activate and deactivate the mod.

Navigate around with W/A/S/D as if you were walking, hold SPACE to go up, hold LCTRL to go down, hold LSHIFT to sprint.